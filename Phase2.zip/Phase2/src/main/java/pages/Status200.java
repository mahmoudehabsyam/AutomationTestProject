package pages;

import org.openqa.selenium.WebDriver;

public class Status200 {
    WebDriver driver;

    public Status200(WebDriver driver) {
        this.driver = driver;
    }



}
