package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class TyposPage {
    WebDriver driver;
    public TyposPage(WebDriver driver){
        this.driver=driver;
    }

    }



