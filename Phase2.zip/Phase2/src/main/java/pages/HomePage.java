package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
    WebDriver driver;

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    private By formAuthenticationLink = By.linkText("Form Authentication");
    private By StatusTest = By.linkText("Status Codes");

    private By UploadFiles = By.linkText("File Upload");
    private By AbTesting = By.linkText("A/B Testing");

    private By TyposPage = By.linkText("Typos");
    private By AddRemovePage = By.linkText("Add/Remove Elements");







    public LoginPage clickOnFormAuthenticationLink(){
        driver.findElement(formAuthenticationLink).click();
        return new LoginPage(driver);
    }
    public StatusPage clickOnStatus (){
        driver.findElement(StatusTest).click();
        return new StatusPage(driver);

    }
    public UploadFiles clickOnUploadFiles (){
        driver.findElement(UploadFiles).click();
        return new UploadFiles(driver);

    }
    public AbTesting clickOnAbtest(){
        driver.findElement(AbTesting).click();
        return new AbTesting(driver);
    }
    public TyposPage clickOnTypos(){
        driver.findElement(TyposPage).click();
        return new TyposPage(driver);
    }
    public AddRemovePage clickOnAddRemove(){
        driver.findElement(AddRemovePage).click();
        return new AddRemovePage(driver);
    }




}