package pages;

import org.openqa.selenium.WebDriver;

public class Confrimation200 {
    WebDriver driver;
    public Confrimation200(WebDriver driver) {
        this.driver = driver;
    }



}
