package pages;

import org.openqa.selenium.WebDriver;

public class AbTesting {
    WebDriver driver;

    public AbTesting(WebDriver driver) {
        this.driver = driver;
    }

}
